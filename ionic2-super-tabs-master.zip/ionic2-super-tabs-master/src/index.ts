export * from './components/super-tab';
export * from './components/super-tabs';
export * from './providers/super-tabs-controller';
export * from './super-tabs.module';
